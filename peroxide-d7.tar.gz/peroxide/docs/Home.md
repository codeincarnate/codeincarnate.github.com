Peroxide
=============

Peroxide is a Drupal theme engine allowing templates to be created using Haml
and stylesheets to be written using Sass and Scss.

Templates and styles for large sites can become quite long and complex.  The goal of this
project is to make more advanced tools available to developers so that the code for themes
is shorter, easier to understand and more maintainable.

Peroxide automatically compiles and caches templates as PHP. Sass and Scss files are also
automatically compiled, cached and their resultant output css is automatically added to a page.

Alongside of peroxide, a kickstarter theme is being developed to make getting started
easier.  It can be found at https://github.com/codeincarnate/peroxide_theme


## Learning

Not everyone is familiar with Haml and Sass.  The documentation below should help you get started on your way!

### Haml

1. [[Haml Introduction]]
1. [[Haml Templates]]
1. [[Haml Templates Advanced]]
1. [[Haml Adding Logic]]

### Sass

1. [[Sass Introduction]]
2. [[Sass vs Scss]]
3. [[Sass Mixins and more]]
4. [[Sass with Compass]]

### API

Peroxide provides a number of hooks to allow modules
to changes options for the underlying parsers, to add Sass
extenions, and to expose increased functionality to the engine.

1. [[Hooks]]
