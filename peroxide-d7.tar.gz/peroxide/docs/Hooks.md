
**hook_peroxide_sass_options_alter(&$options, $theme)**

Allows for alterations of Sass parser options by modules and themes.
$options will be an array of options and $theme will be an object of $stdClass
with information for the currently activated theme.


**hook_peroxide_haml_options_alter(&$options, $theme)**

Allows for alterations of Haml parser options by modules and themes.
$options will be an array of options and $theme will be an object of $stdClass
with information for the currently activated theme.
