This theme engine is made available under the terms of the GPLv2.
For the full text of this license see http://www.gnu.org/licenses/gpl-2.0.html