The peroxide theme is a basic theme using the peroxide theme engine.
The end goal is to make this a powerful base theme for quickly building
out entire Drupal themes.

To use the peroxide theme you must download and install the peroxide theme
engine which can be found at https://github.com/codeincarnate/peroxide
